<footer class="p-4 border-t-2">
    <p class="text-center">Unicorns rule Scotland</p>
  </footer>