/*import { error } from "@sveltejs/kit";

export const load = ({ params }) => {
  if (params.action !== "name") {
    throw error(404, "Page not found.");
  }

  return params;
};*/