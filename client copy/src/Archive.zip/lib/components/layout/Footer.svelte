<footer class="p-4 border-t-2">
    <p class="text-center">Designed and developed by Alischa Thomas</p>
</footer>