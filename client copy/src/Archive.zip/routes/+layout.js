// export const prerender = true; // This instructs Svelte to pre-render all pages, which means that the pages are generated as static HTML files that can be served as-is.
// export const ssr = false;