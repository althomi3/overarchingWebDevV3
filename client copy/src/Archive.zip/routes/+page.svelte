<script>
  import Questions from "$lib/components/Questions.svelte";

</script>

<div class="flex space-x-4">
  <h1 class="text-5xl mb-8">Welcome!</h1>
  <p class="text-5xl">🌬️</p>
</div>



<!--<Questions />

<h1 title="Home">Home</h1>
<p>Welcome</p>-->




